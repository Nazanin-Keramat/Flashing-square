#Comparison 

if 5 > 2:
  print("Five is greater than two!")

# function square root 

import math

x = math.sqrt(64)

print(x) 